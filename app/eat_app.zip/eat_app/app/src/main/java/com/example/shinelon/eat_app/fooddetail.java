package com.example.shinelon.eat_app;

import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.TextView;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;

/**
 * Created by Shinelon on 17/10/2019.
 */

public class fooddetail extends AppCompatActivity  {
    TextView fooddisc;
    NumberPicker numberPicker;
    TextView textView1;
    Intent intent;
    Button addtocart;
    ImageView foodpic;
    TextView foodname;
    TextView numberofchoice;
    //NumberPicker  NumberPicker;
    ConstraintLayout constraintLayout;
    LinearLayout linearLayout;
    public fooddetail() {
        // Required empty public constructor
    }


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        Intent intent = getIntent();
        int foodID = intent.getIntExtra("foodID", 0);

        Food food = Database.getFoodById(foodID);
        setContentView(R.layout.fooddetail);
        foodname = findViewById(R.id.fooodname);
        foodpic = findViewById(R.id.foodpic);
        addtocart = findViewById(R.id.addtocart);
        fooddisc = findViewById(R.id.fooddisc);
        addtocart = findViewById(R.id.addtocart);
        //  numberPicker = findViewById(R.id.numberpicker);
        //    constraintLayout = findViewById(R.id.layoutpicker);
        //  linearLayout = findViewById(R.id.linearlayout2);

        //Spinner spinner = findViewById(R.id.spinner);

         intent = getIntent();
        // NumberPicker.setOnClickListener((View.OnClickListener) this);
        foodpic.setImageResource(food.getImageDrawableId());
        fooddisc.setText(food.getFoodDesc());
        fooddisc.setText(food.getFoodDesc());
        foodname.setText(food.getFoodName());
        final ElegantNumberButton elegantNumberButton = findViewById(R.id.numberbutton);
        elegantNumberButton.setOnClickListener(new ElegantNumberButton.OnClickListener() {
            @Override
            public void onClick(View view) {
                String num = elegantNumberButton.getNumber();
            }
        });

        addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });




    }

}
